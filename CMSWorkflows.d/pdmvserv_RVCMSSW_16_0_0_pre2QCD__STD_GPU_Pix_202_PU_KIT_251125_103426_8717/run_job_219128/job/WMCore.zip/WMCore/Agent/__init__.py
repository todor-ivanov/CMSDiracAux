#!/usr/bin/env python
"""
__init__

Module containing common components for creating
components.

"""
