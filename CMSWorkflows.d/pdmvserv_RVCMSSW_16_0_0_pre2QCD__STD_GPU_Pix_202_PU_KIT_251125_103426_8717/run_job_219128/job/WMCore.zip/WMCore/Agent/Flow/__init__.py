#!/usr/bin/env python
"""
__init__

Module for generating lifecycle workflow component stubs,
so developers can easily migrate their handlers without
worrying to much about the structure and framework.


"""
