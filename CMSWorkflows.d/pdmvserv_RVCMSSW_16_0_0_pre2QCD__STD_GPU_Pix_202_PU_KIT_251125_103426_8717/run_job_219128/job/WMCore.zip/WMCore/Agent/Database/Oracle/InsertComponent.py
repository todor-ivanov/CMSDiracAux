"""
_InsertComponent_

Oracle implementation of InsertComponent
"""

__all__ = []



from WMCore.Agent.Database.MySQL.InsertComponent import InsertComponent \
     as InsertComponentMySQL

class InsertComponent(InsertComponentMySQL):
    pass
