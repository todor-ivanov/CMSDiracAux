from __future__ import print_function, division
#filtered list which only send list information for DAS query
DAS_RESULT_FILTER = {"filter_list": ["RequestName", "PrepID", "CMSSWVersion", "GlobalTag"]}
