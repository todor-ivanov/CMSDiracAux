"""
List of valid request types.

"""

REQUEST_TYPES = [
    "ReReco",
    "StoreResults",
    "Resubmission",
    "TaskChain",
    "DQMHarvest",
    "StepChain"
]
