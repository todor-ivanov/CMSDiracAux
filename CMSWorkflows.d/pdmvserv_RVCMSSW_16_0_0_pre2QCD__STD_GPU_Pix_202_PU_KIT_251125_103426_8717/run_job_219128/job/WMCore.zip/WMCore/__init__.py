#!/usr/bin/env python
"""
_WMCore_

Core libraries for Workload Management Packages

"""

__version__ = '2.4.5.1'
__all__ = []
