#!/usr/bin/env python
"""
_DataStructs_

A set of base objects to be used/inherited elsewhere

"""
__all__ = []
