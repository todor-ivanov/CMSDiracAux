#!/usr/bin/env python
"""
_ListThresholds_

This module list thresholds for the given sites for Oracle
"""


from WMCore.ResourceControl.MySQL.ListThresholds import ListThresholds \
  as ListThresholdsMySQL
class ListThresholds(ListThresholdsMySQL):
    pass
