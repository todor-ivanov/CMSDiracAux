#/usr/bin/env python
"""
_Destroy_

Oracle implementation of ResourceControl.Destroy.
"""




from WMCore.ResourceControl.MySQL.Destroy import Destroy as MySQLDestroy

class Destroy(MySQLDestroy):
    pass
